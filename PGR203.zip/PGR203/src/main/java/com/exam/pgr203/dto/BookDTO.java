package com.exam.pgr203.dto;


import lombok.Data;
import java.util.Date;

@Data
public class BookDTO {
    private Integer id;
    private String name;
    private Date publishedDate;
    private String isbn;
    private String description;
}
