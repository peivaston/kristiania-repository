package com.exam.pgr203.service;

import com.exam.pgr203.dto.BookDTO;
import com.exam.pgr203.mapper.BookMapper;
import com.exam.pgr203.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookService {

    @Autowired
    BookRepository bookRepository;

    public void save(BookDTO bookDTO){
        bookRepository.save(BookMapper.toModel(bookDTO));
    }

    public List<BookDTO> getAllBooks(){
      return BookMapper.toBookDTOs(bookRepository.findAll());
    }

    public BookDTO getBookById(Integer id){
        return BookMapper.toBookDTO(bookRepository.findById(id).get());
    }

    public void deleteById(Integer id){
        bookRepository.deleteById(id);
    }
}
