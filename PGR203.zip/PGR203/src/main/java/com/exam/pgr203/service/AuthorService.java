package com.exam.pgr203.service;

import com.exam.pgr203.dto.AuthorDTO;
import com.exam.pgr203.mapper.AuthorMapper;
import com.exam.pgr203.repository.AuthorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AuthorService {

    @Autowired
    AuthorRepository authorRepository;

    public void saveAuthor(AuthorDTO authorDTO) {
        authorRepository.save(AuthorMapper.toAuthorEntity(authorDTO));
    }

    public List<AuthorDTO> getAllAuthors() {
        return AuthorMapper.getAuthorDTOs(authorRepository.findAll());
    }

    public AuthorDTO getAuthor(int id) {
        return AuthorMapper.toAuthorDTO(authorRepository.findById(id).get());
    }

    public void deleteAuthorById(int id) {
        authorRepository.deleteById(id);
    }
}
