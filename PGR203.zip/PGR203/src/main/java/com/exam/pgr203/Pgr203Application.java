package com.exam.pgr203;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Pgr203Application {

    public static void main(String[] args) {
        SpringApplication.run(Pgr203Application.class, args);
    }

}
