package com.exam.pgr203.mapper;

import com.exam.pgr203.dto.AuthorDTO;
import com.exam.pgr203.entity.Author;
import com.exam.pgr203.entity.Book;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class AuthorMapper {

    public static AuthorDTO toAuthorDTO(Author author) {
        if (author == null) {
            return null;
        }
        AuthorDTO authorDTO = new AuthorDTO();
        Book book = author.getBook();
        authorDTO.setBookId(book.getId());
        authorDTO.setFirstName(author.getFirstName());
        authorDTO.setLastName(author.getLastName());
        authorDTO.setId(author.getId());
        return authorDTO;
    }

    public static Author toAuthorEntity(AuthorDTO authorDTO) {
        Author author = new Author();
        Book book = new Book();
        book.setId(authorDTO.getBookId());
        author.setBook(book);
        author.setLastName(authorDTO.getLastName());
        author.setFirstName(authorDTO.getFirstName());
        if (authorDTO.getId() != null) {
            author.setId(authorDTO.getId());
        }
        return author;
    }

    public static List<AuthorDTO> getAuthorDTOs(List<Author> authors) {
        return authors.stream().filter(Objects::nonNull).map(author -> toAuthorDTO(author)).collect(Collectors.toList());
    }

}
