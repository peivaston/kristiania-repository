package com.exam.pgr203.entity;

import lombok.Data;

import javax.persistence.*;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

@Data
@Entity
public class Book {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;
    private String name;
    @OneToMany(mappedBy = "book")
    private Set<Author> authors = new HashSet<>();
    private String isbn;
    @Temporal(TemporalType.DATE)
    private Date publishedDate;
    private String description;
}
