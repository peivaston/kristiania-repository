package com.exam.pgr203.controller;

import com.exam.pgr203.service.AuthorService;
import com.exam.pgr203.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
/**
 * controller for MVC
 *
 * @author iccdeveloper
 * @since 27-02-2022
 *
 */
@org.springframework.stereotype.Controller
public class Controller {

    @Autowired
    BookService bookService;

    @Autowired
    AuthorService authorService;

    @GetMapping("/dashboard")
    public String getDefaultPage(){
        return "index";
    }

    @GetMapping("/createBook")
    public String createBook(){
        return "createBook";
    }

    @GetMapping("/createAuthor")
    public String createAuthor(){
        return "createAuthor";
    }

    @GetMapping("/editBook")
    public String editBook(@RequestParam int id, Model model){
        model.addAttribute("book",bookService.getBookById(id));
        return "createBook";
    }

    @GetMapping("/editAuthor")
    public String editAuthor(@RequestParam int id, Model model){
        model.addAttribute("author",authorService.getAuthor(id));
        return "createAuthor";
    }
}

