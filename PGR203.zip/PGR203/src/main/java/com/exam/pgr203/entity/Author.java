package com.exam.pgr203.entity;

import lombok.Data;
import org.hibernate.annotations.GeneratorType;

import javax.persistence.*;


@Data
@Entity
public class Author {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;
    private String firstName;
    private String lastName;
    @ManyToOne
    private Book book;
}
