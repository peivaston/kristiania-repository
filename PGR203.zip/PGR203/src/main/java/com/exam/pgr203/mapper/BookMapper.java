package com.exam.pgr203.mapper;

import com.exam.pgr203.dto.BookDTO;
import com.exam.pgr203.entity.Book;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class BookMapper {
    public static Book toModel(BookDTO bookDTO) {
        Book book = new Book();
        book.setIsbn(bookDTO.getIsbn());
        book.setName(bookDTO.getName());
        book.setDescription(bookDTO.getDescription());
        book.setPublishedDate(bookDTO.getPublishedDate());
        if (bookDTO.getId() != null) {
            book.setId(bookDTO.getId());
        }
        return book;
    }

    public static List<BookDTO> toBookDTOs(List<Book> books) {
        return books.stream().filter(Objects::nonNull).map(book -> toBookDTO(book)).collect(Collectors.toList());

    }

    public static BookDTO toBookDTO(Book book) {
        if (book == null) {
            return null;
        }
        BookDTO bookDTO = new BookDTO();
        bookDTO.setId(book.getId());
        bookDTO.setIsbn(book.getIsbn());
        bookDTO.setName(book.getName());
        bookDTO.setPublishedDate(book.getPublishedDate());
        bookDTO.setDescription(book.getDescription());
        return bookDTO;
    }
}
