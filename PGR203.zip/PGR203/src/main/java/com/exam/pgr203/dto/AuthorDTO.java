package com.exam.pgr203.dto;


import lombok.Data;


@Data
public class AuthorDTO {
    private Integer id;
    private String firstName;
    private String lastName;
    private int bookId;
}
