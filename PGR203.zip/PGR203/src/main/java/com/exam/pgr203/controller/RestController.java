package com.exam.pgr203.controller;

import com.exam.pgr203.dto.AuthorDTO;
import com.exam.pgr203.dto.BookDTO;
import com.exam.pgr203.service.AuthorService;
import com.exam.pgr203.service.BookService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

/**
 * controller for manage user Entity
 *
 *
 */
@org.springframework.web.bind.annotation.RestController
@RequestMapping("/api")
@Slf4j
public class RestController {

    @Autowired
    BookService bookService;

    @Autowired
    AuthorService authorService;

    @PostMapping("/createNewBook")
    public ResponseEntity<BookDTO> createNewBook(@RequestBody BookDTO bookDTO) {
        log.debug("createNewBook invoked");
        bookService.save(bookDTO);
        return new ResponseEntity<>(bookDTO, HttpStatus.SEE_OTHER);
    }

    @PostMapping("/createNewAuthor")
    public ResponseEntity<AuthorDTO> createNewAuthor(@RequestBody AuthorDTO authorDTO) {
        log.debug("createNewAuthor invoked");
        authorService.saveAuthor(authorDTO);
        return new ResponseEntity<>(authorDTO, HttpStatus.SEE_OTHER);
    }

    @GetMapping("/getAllBooks")
    public ResponseEntity<List> getAllBooks() {
        log.debug("getAllBooks invoked");
        return new ResponseEntity<>(bookService.getAllBooks(), HttpStatus.OK);
    }

    @GetMapping("/getAllAuthors")
    public ResponseEntity<List> getAllAuthors() {
        log.debug("getAllAuthors invoked");
        return new ResponseEntity<>(authorService.getAllAuthors(), HttpStatus.OK);
    }

}
